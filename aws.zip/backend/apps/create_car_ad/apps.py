from django.apps import AppConfig


class CreateCarApplicationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.create_car_ad'
